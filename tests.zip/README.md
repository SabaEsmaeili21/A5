# UTGame Test Pack — runner-style layout

This pack matches the folder convention used by your previous Bash test runner.

## Folder structure

```text
data/
  players.csv
  admins.csv
tests/
  01/
    01.in
    01.out
  02/
    02.in
    02.out
  ...
run_tests.sh
test_index.txt
```

## How to use it

Copy `tests/`, `data/`, and `run_tests.sh` into your project root, beside the `UTGame` executable. Then run:

```bash
chmod +x run_tests.sh
./run_tests.sh
```

Your executable is expected to run as:

```bash
./UTGame ./data/players.csv ./data/admins.csv
```

The script intentionally uses `diff -w`, matching your old runner. This ignores whitespace differences. Before final submission, remove `-w` and use exact comparison because the assignment's automated tests may care about spaces and newlines.

Use `test_index.txt` to see what each numbered test covers.
