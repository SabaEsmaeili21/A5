#!/bin/bash

# Run from your project root after copying the tests/ and data/ folders there.
# Your executable must be named UTGame.

passed=0
failed=0

for dir in tests/*
do
    num=$(basename "$dir")
    ./UTGame ./data/players.csv ./data/admins.csv < "$dir/$num.in" > output.txt

    # Use -w to match your previous runner behavior.
    # Remove -w if you want to enforce exact whitespace as required by the assignment.
    if diff -w output.txt "$dir/$num.out" > /dev/null;
    then
        echo "Test $num: PASS"
        passed=$((passed + 1))
    else
        echo "Test $num: FAIL"
        echo "Run this to see the difference:"
        echo "diff -u output.txt $dir/$num.out"
        failed=$((failed + 1))
    fi
done

echo
echo "Passed: $passed"
echo "Failed: $failed"
